import React from "react";
function App() { return <div className="p-4">AI Resume Builder by jyothibadana</div>; }
export default App;